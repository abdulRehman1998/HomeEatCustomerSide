package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.adapters.horizontalAdapter;

public class OrderPage extends AppCompatActivity {

    RecyclerView orderAgain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);

        LinearLayoutManager layoutManager= new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        orderAgain=(RecyclerView) findViewById(R.id.list_orderagain);
        orderAgain.setLayoutManager(layoutManager);
        horizontalAdapter adapterVideo = new horizontalAdapter(this);
        orderAgain.setAdapter(adapterVideo);


    }
}
